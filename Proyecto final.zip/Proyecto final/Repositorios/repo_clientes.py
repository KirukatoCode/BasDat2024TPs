import tkinter as tk
from tkinter import messagebox
from Clientes import Cliente

def mostrar_actualizacion_cliente(cliente_db):


    ventana = tk.Toplevel()
    ventana.geometry("640x480+500+300")
    ventana.title("Actualizar Cliente")

    listbox = tk.Listbox(ventana)
    listbox.pack(fill=tk.BOTH, expand=True)

    clientes = cliente_db.ver_clientes()
    for cliente in clientes:
        listbox.insert(tk.END, f"{cliente[0]} - {cliente[1]} {cliente[2]}")

    def actualizar_cliente():
        seleccion = listbox.curselection()
        if not seleccion:
            messagebox.showwarning("Seleccionar Cliente", "Debe seleccionar un cliente para actualizar.")
            return
        cliente_id = clientes[seleccion[0]][0]
        cliente_actual = cliente_db.ver_cliente(cliente_id)[0]
        actualizacion_ventana = tk.Toplevel()
        actualizacion_ventana.title("Editar datos del Cliente")
        actualizacion_ventana.geometry("500x400")

        actualizacion_ventana.grid_columnconfigure(0, weight=1)  # Columna de etiquetas
        actualizacion_ventana.grid_columnconfigure(1, weight=3)  # Columna de entradas

        tk.Label(actualizacion_ventana, text="Nombre:").grid(row=0, column=0, padx=10, pady=10, sticky="e")
        nombre_entry = tk.Entry(actualizacion_ventana)
        nombre_entry.insert(0, cliente_actual[1])
        nombre_entry.grid(row=0, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")

        tk.Label(actualizacion_ventana, text="Apellido:").grid(row=1, column=0, padx=10, pady=10, sticky="e")
        apellido_entry = tk.Entry(actualizacion_ventana)
        apellido_entry.insert(0, cliente_actual[2])
        apellido_entry.grid(row=1, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")

        tk.Label(actualizacion_ventana, text="Teléfono:").grid(row=2, column=0, padx=10, pady=10, sticky="e")
        telefono_entry = tk.Entry(actualizacion_ventana)
        telefono_entry.insert(0, cliente_actual[3])
        telefono_entry.grid(row=2, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")

        tk.Label(actualizacion_ventana, text="Email:").grid(row=3, column=0, padx=10, pady=10, sticky="e")
        email_entry = tk.Entry(actualizacion_ventana)
        email_entry.insert(0, cliente_actual[4])
        email_entry.grid(row=3, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")
        #Toma el id del cliente y se le asigna un valor nuevo a elemento del objeto cliente


        def validar_datos():
            nombre = nombre_entry.get().strip()
            apellido = apellido_entry.get().strip()
            telefono = telefono_entry.get().strip()
            email = email_entry.get().strip()
            

            # Validamos que los campos no estén vacíos y tengan valores que sean utiles
            if not nombre:
                messagebox.showerror("Error de Validación", "El nombre no puede estar vacío.")
                return False
            if not apellido:
                messagebox.showerror("Error de Validación", "El apellido no puede estar vacío.")
                return False
            if not telefono.replace('.', '', 1).isdigit():
                messagebox.showerror("Error de Validación", "El telefono debe ser un número válido.")
                return False
            if not email:
                messagebox.showerror("Error de Validación", "El correo electronico no puede estar vacio.")
                return False
            

            return True

        def guardar_cambios():

            if validar_datos():
                nombre = nombre_entry.get()
                apellido = apellido_entry.get()
                telefono = telefono_entry.get()
                email = email_entry.get()
                
                
                cliente_db.actualizar_cliente(cliente_id, nombre, apellido, telefono, email)
                messagebox.showinfo("Éxito", "Cliente actualizado con éxito.")
                actualizacion_ventana.destroy()

        tk.Button(actualizacion_ventana, text="Guardar Cambios", command=guardar_cambios, bd=1).grid(row=5, column=0, columnspan=2, pady=20)

    tk.Button(ventana, text="Actualizar Cliente Seleccionado", command=actualizar_cliente, bd=1).pack(pady=10)
    
def buscar_clientes(cliente_db):
    window = tk.Toplevel()
    window.geometry("400x170+500+300")  # Configura el tamaño y posición de la ventana
    window.title("Buscar Clientes")  # Título de la ventana
    window.grid_columnconfigure(0, weight=1)
    window.grid_columnconfigure(1, weight=3)

    tk.Label(window, text="Ingrese un cliente").grid(row=0, column=0, columnspan=2, pady=20)
    tk.Label(window, text="Nombre:").grid(row=1, column=0, padx=10, pady=10, sticky="e")
    nombre_entry = tk.Entry(window)
    nombre_entry.grid(row=1, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")


    def abrir_lista_clientes():
        nombre_cliente = nombre_entry.get().strip() 
        window.destroy()

        # Creamos una nueva ventana que nos permita ver la lista de clientes
        list_window = tk.Toplevel()
        list_window.title("Cliente encontrado")
        list_window.geometry("640x480")

        # Configuración de la grilla de la nueva ventana
        list_window.grid_columnconfigure(0, weight=1)
        list_window.grid_columnconfigure(1, weight=1)

        # Listbox para mostrar los clientes
        listbox = tk.Listbox(list_window)
        listbox.grid(row=0, column=0, columnspan=2, padx=10, pady=10, sticky="nsew")

        # Buscar clientes en la base de datos usando el nombre ingresado
        clientes = cliente_db.buscar_cliente_por_nombre(nombre_cliente)  # Recupera los clientes que compartan el nombre
        for cliente in clientes:
            listbox.insert(tk.END, f"{cliente[0]} - {cliente[1]} {cliente[2]}")  # Muestra ID, nombre y apellido

        def editar_cliente():
            seleccion = listbox.curselection()  # Obtiene el índice del cliente seleccionado
            if not seleccion:
                messagebox.showwarning("Error", "Seleccione un cliente para editar.")
                return

            cliente_id = clientes[seleccion[0]][0]  # Obtiene el ID del cliente seleccionado
            cliente_actual = cliente_db.ver_cliente(cliente_id)[0]  

            edit_window = tk.Toplevel()
            edit_window.title("Editar Cliente")
            edit_window.geometry("400x300")
            for i in range(2):
                edit_window.grid_columnconfigure(i, weight=1)

            # Creamos etiquetas para los datos del cliente
            fields = ["Nombre", "Apellido", "Telefono", "Direccion", "Email"]
            entries = {}  #Guardamos los datos ingresados en un diccionario
            for idx, field in enumerate(fields):
                tk.Label(edit_window, text=f"{field}:").grid(row=idx, column=0, padx=10, pady=5, sticky="e")
                entry = tk.Entry(edit_window)
                entry.grid(row=idx, column=1, padx=10, pady=5, ipadx=10, sticky="ew")
                entry.insert(0, str(cliente_actual[idx + 1])) #Utiliza los datos actuales del cliente
                entries[field.lower()] = entry

            # Guardamos cambios
            def guardar_cambios():
                try:
                    #Valida los datos ingresados
                    datos = {
                        "nombre": entries["nombre"].get().strip(),
                        "apellido": entries["apellido"].get().strip(),
                        "telefono": int(entries["telefono"].get()),
                        "direccion": entries["direccion"].get(),
                        "email": entries["email"].get().strip()
                    }
                except ValueError:
                    # Sale un error si hay algun problema con los datos
                    messagebox.showerror("Error, intente nuevamente")
                    return

                # Actualiza el cliente en la base de datos
                cliente_db.actualizar_cliente(cliente_id, **datos)
                messagebox.showinfo("Cliente actualizado con éxito.")
                edit_window.destroy() 

            # Botón para guardar los cambios
            tk.Button(edit_window, text="Guardar Cambios", command=guardar_cambios).grid(
                row=len(fields), column=0, columnspan=2, pady=10
            )

        def eliminar_cliente():
            seleccion = listbox.curselection()
            if not seleccion:
                # Muestra una advertencia si no se selecciona ningún cliente
                messagebox.showwarning("Seleccione un cliente.")
                return

            cliente_id = clientes[seleccion[0]][0]  # Obtiene el ID del cliente 
            messagebox.showinfo("Éxito", "Cliente eliminado con éxito.")#Elimina el cliente

        tk.Button(list_window, text="Editar Cliente", command=editar_cliente, bd=1).grid(row=1, column=0, pady=10, padx=5, sticky="e")
        tk.Button(list_window, text="Eliminar Cliente", command=eliminar_cliente, bd=1).grid(row=1, column=1, pady=10, padx=5, sticky="w")

    tk.Button(window, text="Buscar Cliente", command=abrir_lista_clientes, bd=1).grid(row=2, column=0, columnspan=2,)
    
def Registrar_nuevo_cliente(cliente_db):
    ventana = tk.Toplevel()
    ventana.geometry("700x300+500+500")
    ventana.title("Nuevo cliente")
    
    tk.Label(ventana, text="Nombre:").grid(row=0, column=0, padx=5, pady=10)
    nombre_entry = tk.Entry(ventana)
    nombre_entry.grid(row=0, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")

    tk.Label(ventana, text="Apellido:").grid(row=1, column=0, padx=5, pady=10)
    apellido_entry = tk.Entry(ventana)
    apellido_entry.grid(row=1, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")

    tk.Label(ventana, text="Teléfono:").grid(row=2, column=0, padx=5, pady=10)
    telefono_entry = tk.Entry(ventana)
    telefono_entry.grid(row=2, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")

    tk.Label(ventana, text="Email:").grid(row=3, column=0, padx=5, pady=10)
    email_entry = tk.Entry(ventana)
    email_entry.grid(row=3, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")


    def registrar_cliente():
        nombre = nombre_entry.get()
        apellido = apellido_entry.get()
        telefono = telefono_entry.get()
        email = email_entry.get()
        # Validaciones
        if not nombre:
            messagebox.showerror("El campo 'Nombre' es obligatorio.")
            return
        if not apellido:
            messagebox.showerror("El campo 'Apellido' es obligatorio.")
            return
        if not email:
            messagebox.showerror("El campo 'Email' es obligatorio.")
            return
        cliente_db.registrar_cliente(nombre, apellido, telefono, email)
        messagebox.showinfo("Cliente registrado con éxito.")
        ventana.destroy()

    tk.Button(ventana, text="Registrar Cliente", command=registrar_cliente, bd=1).grid(row=5, columnspan=2, pady=20)

def mostrar_clientes(cliente_db):
    ventana = tk.Toplevel()
    ventana.geometry("640x480+500+300")
    ventana.title("Ver Clientes")
    
    listbox = tk.Listbox(ventana)
    listbox.pack(fill=tk.BOTH, expand=True)

    for cliente in cliente_db.ver_clientes():
        listbox.insert(tk.END, f"ID: {cliente[0]}  - {cliente[1]} {cliente[2]}")