import tkinter as tk
from tkinter import messagebox

def mostrar_registro_ordenes(cliente_db, producto_db, ordenes_db):
    window = tk.Toplevel()
    window.geometry("640x480+500+300")
    window.title("Registro de Nuevas Ordenes de Compra")
    listbox = tk.Listbox(window)
    listbox.pack(fill=tk.BOTH, expand=True)
    prod_list = producto_db.VerProducto()
    for prd in prod_list:
        listbox.insert(tk.END, f"{prd[0]} - {prd[1]} {prd[2]}")

    def generar_usuarios():
        seleccion = listbox.curselection()
        if not seleccion:
            messagebox.showwarning("Seleccionar Producto")
            return
        producto_id = prod_list[seleccion[0]][0]
        actualizacion_window = tk.Toplevel()
        actualizacion_window.title("Generar Orden de Usuario")
        actualizacion_window.geometry("500x300")
        actualizacion_window.grid_columnconfigure(0, weight=1)
        actualizacion_window.grid_columnconfigure(1, weight=3)

        tk.Label(actualizacion_window, text=" --- Usuarios Registrados ---", font=("Arial", 13, "bold")).grid(row=0, column=0)
        usuarios_registrados = tk.StringVar()
        clientes = cliente_db.ver_cliente()
        opciones = [(f"{cliente[1]} {cliente[2]}", cliente[0]) for cliente in clientes]

        if opciones:
            usuarios_registrados.set("Seleccione una Opcion")
        def obtener_seleccion():
            nombre_seleccionado = usuarios_registrados.get()
            return next((cliente_id for nombre, cliente_id in opciones if nombre == nombre_seleccionado), None)
        menu_registrados = tk.OptionMenu(actualizacion_window, usuarios_registrados, *[opcion[0] for opcion in opciones])
        menu_registrados.config(bd=1)
        menu_registrados.grid(row=1, column=0, sticky="ew", padx=15, pady=10)
        
        tk.Label(actualizacion_window, text=" --- Producto ---", font=("Arial", 13, "bold")).grid(row=2, column=0, pady=10)
        tk.Label(actualizacion_window, text="Cantidad:").grid(row=3, column=0, padx=10, pady=10, sticky="e")
        cantidad_entry = tk.Entry(actualizacion_window)
        cantidad_entry.grid(row=3, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")

        def finalizar_orden():
            
            cliente_id = obtener_seleccion()
            cantidad = int(cantidad)
            ordenes_db.registrar_orden(producto_id, cliente_id, cantidad)

            messagebox.showinfo("Nueva Orden de compra generada")
            actualizacion_window.destroy()
            window.destroy()

        boton_mostrar = tk.Button(actualizacion_window, text="Finalizar Orden", command=finalizar_orden, bd=1)
        boton_mostrar.grid(row=4, column=0, pady=20)

    tk.Button(window, text="Generar Orden", command=generar_usuarios, bd=1).pack(pady=10)
    window.mainloop()

def mostrar_ordenes_cliente(cliente_db, ordenes_db):
    ventana = tk.Toplevel()
    ventana.geometry("640x480+500+300")
    ventana.title("Ver órdenes del cliente")
    listbox = tk.Listbox(ventana)
    listbox.pack(fill=tk.BOTH, expand=True)
    clientes = cliente_db.ver_cliente()
    for cliente in clientes:
        listbox.insert(tk.END, f"{cliente[0]} - {cliente[1]} {cliente[2]}")

    def ver_ordenes_id():
        seleccion = listbox.curselection()
        if not seleccion:
            messagebox.showwarning("Seleccionar Cliente")
            return

        cliente_id = clientes[seleccion[0]][0]
        
        ord_ventana = tk.Toplevel()
        ord_ventana.geometry("640x480+500+300")
        ord_ventana.resizable(False, False)
        ord_ventana.title("Órdenes del cliente")
        
        ord_listbox = tk.Listbox(ord_ventana)
        ord_listbox.pack(fill=tk.BOTH, expand=True)
        ordenes = ordenes_db.ver_orden_id(cliente_id)
        for orden in ordenes:
            ord_listbox.insert(tk.END, f"{orden[0]} - {orden[1]} ({orden[2]})") 
            
            
        def editar_orden_seleccionada():
            
            orden_id = ordenes[seleccion[0]][0]
            orden_actual = ordenes_db.ver_orden_id(orden_id)[0]
            edit_window = tk.Toplevel()
            edit_window.geometry("400x160+600+500")
            edit_window.title("Editar orden")

            tk.Label(edit_window, text="Stock:").grid(row=0, column=0, padx=10, pady=10, sticky="e")
            stock_entry = tk.Entry(edit_window)
            stock_entry.insert(0, orden_actual[4])
            stock_entry.grid(row=0, column=1, padx=10, pady=10)

            tk.Label(edit_window, text=f"Stock máximo: {orden_actual[5]}", fg="red").grid(row=0, column=2, padx=10, pady=10)

            def guardar_cambios():
                nuevo_stock = stock_entry.get()
                nuevo_stock = int(nuevo_stock)
                if nuevo_stock > orden_actual[5]:
                    messagebox.showerror("Stock maximo alcanzado")
                    return

                ordenes_db.actualizar_orden(orden_id, nuevo_stock)
                messagebox.showinfo("Orden de compra actualizada.")
                edit_window.destroy()
                
            tk.Button(edit_window, text="Guardar Orden", command=guardar_cambios, bd=1).grid(row=1, column=0, columnspan=3, pady=20)

        def eliminar_orden_seleccionada():
            seleccion = ord_listbox.curselection()
            if not seleccion:
                messagebox.showwarning("Seleccione una orden para eliminar.")
                return

            orden_id = ordenes[seleccion[0]][0]
            ordenes_db.eliminar_orden(orden_id)
            ord_listbox.delete(seleccion)
            messagebox.showinfo("Orden de compra eliminada")

        tk.Button(ord_ventana, text="Editar Orden", command=editar_orden_seleccionada, bd=1).pack(pady=10)
        tk.Button(ord_ventana, text="Eliminar Orden", command=eliminar_orden_seleccionada, bd=1).pack(pady=10)
        
    tk.Button(ventana, text="Ver órdenes", command=ver_ordenes_id, bd=1).pack(pady=10)