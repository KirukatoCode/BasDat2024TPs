import tkinter as tk
from tkinter import messagebox, ttk
from Entidades.Producto import Producto

def actualizar_productos(producto_db):

    window = tk.Toplevel()
    window.geometry("640x480+500+300")
    window.title("Actualizar productos")  # Título de la ventana

    # Listbox para mostrar los productos disponibles
    listbox = tk.Listbox(window)
    listbox.pack(fill=tk.BOTH, expand=True)

    prod_list = producto_db.VerProducto()  
    for prd in prod_list:
        listbox.insert(tk.END, f"ID: {prd[0]}   |    Nombre: {prd[1]}   |   Precio: ${prd[3]}   |   Stock: {prd[4]}")

    def actualizar_producto():
       
        seleccion = listbox.curselection()
        if not seleccion:
            messagebox.showwarning("Seleccionar Producto")
            return

        producto_id = prod_list[seleccion[0]][0]
        producto_actual = producto_db.VerProducto(producto_id)[0]

        actualizacion_window = tk.Toplevel()
        actualizacion_window.title("Editar datos del producto")
        actualizacion_window.geometry("500x400") 
        actualizacion_window.grid_columnconfigure(0, weight=1)
        actualizacion_window.grid_columnconfigure(1, weight=3)

        tk.Label(actualizacion_window, text="Nombre:").grid(row=0, column=0, padx=10, pady=10, sticky="e")
        nombre_entry = tk.Entry(actualizacion_window)
        nombre_entry.insert(0, producto_actual[1])
        nombre_entry.grid(row=0, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")

        tk.Label(actualizacion_window, text="Descripcion:").grid(row=1, column=0, padx=10, pady=10, sticky="e")
        descripcion_entry = tk.Entry(actualizacion_window)
        descripcion_entry.insert(0, producto_actual[2])
        descripcion_entry.grid(row=1, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")

        tk.Label(actualizacion_window, text="Precio:").grid(row=2, column=0, padx=10, pady=10, sticky="e")
        precio_entry = tk.Entry(actualizacion_window)
        precio_entry.insert(0, producto_actual[3])
        precio_entry.grid(row=2, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")

        tk.Label(actualizacion_window, text="Stock:").grid(row=3, column=0, padx=10, pady=10, sticky="e")
        stock_entry = tk.Entry(actualizacion_window)
        stock_entry.insert(0, producto_actual[4])
        stock_entry.grid(row=3, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")
    
        def guardar_cambios():
           
            nombre = nombre_entry.get()
            descripcion = descripcion_entry.get()
            precio = float(precio_entry.get())
            stock = int(stock_entry.get())
            producto_db.ActualizarProducto(producto_id, nombre, descripcion, precio, stock)
            messagebox.showinfo("El producto se ha actualizado con éxito.")
            actualizacion_window.destroy()

        guardar_btn = tk.Button(actualizacion_window, text="Guardar Cambios", command=guardar_cambios)
        guardar_btn.grid(row=5, column=0, columnspan=2, pady=20)

    tk.Button(window, text="Actualizar producto", command=actualizar_producto).pack(pady=10)

def buscar_productos(producto_db):
    window = tk.Toplevel()
    window.geometry("400x220+500+300")
    window.title("Buscar producto")
    window.grid_columnconfigure(0, weight=1)
    window.grid_columnconfigure(1, weight=3)
    
    tk.Label(window, text="Ingrese el nombre de un producto").grid(row=0, column=0, columnspan=2, pady=20)
    tk.Label(window, text="Nombre:").grid(row=1, column=0, padx=10, pady=10, sticky="e")
    nombre_entry = tk.Entry(window)
    nombre_entry.grid(row=1, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")

    def abrir_lista_productos():
        if not nombre_entry.get():
            messagebox.showwarning("Producto no encontrado")
        else:
            nombre_producto = nombre_entry.get().strip()
            window.destroy() 
            list_window = tk.Toplevel()
            list_window.title("Resultado de la busqueda")
            list_window.geometry("640x480")
            list_window.grid_columnconfigure(0, weight=1)
            list_window.grid_columnconfigure(1, weight=1)
            listbox = tk.Listbox(list_window)
            listbox.grid(row=0, column=0, columnspan=2, padx=10, pady=10, sticky="nsew")
            
            productos = producto_db.BuscarProductoporNombre(nombre_producto)
            for producto in productos:
                listbox.insert(tk.END, f"ID: {producto[0]}   |    Nombre: {producto[1]}   |   Precio: ${producto[3]}   |   Stock: {producto[4]}")


        def editar_producto():
            seleccion = listbox.curselection()
            if not seleccion:
                messagebox.showwarning("Seleccione un producto para modificar.")
                return

            producto_id = productos[seleccion[0]][0]
            producto_actual = producto_db.VerProducto(producto_id)[0]
            edit_window = tk.Toplevel()
            edit_window.title("Editar Producto")
            edit_window.geometry("400x300")

            for i in range(2):
                edit_window.grid_columnconfigure(i, weight=1)
            fields = ["Nombre", "Descripción", "Precio", "Stock"]
            entries = {} 
            for idx, field in enumerate(fields):
                tk.Label(edit_window, text=f"{field}:").grid(row=idx, column=0, padx=10, pady=5, sticky="e")
                entry = tk.Entry(edit_window)
                entry.grid(row=idx, column=1, padx=10, pady=5, ipadx=10, sticky="ew")
                entry.insert(0, str(producto_actual[idx + 1]))
                entries[field.lower()] = entry

            def guardar_cambios():
                try:
                    datos = {
                        "nombre": entries["nombre"].get().strip(),
                        "descripcion": entries["descripción"].get().strip(),
                        "precio": float(entries["precio"].get()),
                        "stock": int(entries["stock"].get()),
                    }
                except ValueError:
                    messagebox.showerror("Datos inválidos")
                    return

                producto_db.ActualizarProducto(producto_id, **datos)
                messagebox.showinfo("Producto actualizado con éxito.")
                edit_window.destroy()

            tk.Button(edit_window, text="Guardar Cambios", command=guardar_cambios).grid(
                row=len(fields), column=0, columnspan=2, pady=10
            )

        def eliminar_producto():
            seleccion = listbox.curselection()  
            if not seleccion:
                messagebox.showwarning("Error", "Seleccione un producto para eliminar.")
                return

            producto_id = productos[seleccion[0]][0]
            producto_db.EliminarProducto(producto_id)  
            messagebox.showinfo("Producto eliminado con éxito.")

        tk.Button(list_window, text="Editar producto", command=editar_producto, bd=1).grid(row=1, column=0, pady=10, padx=5, sticky="e")
        tk.Button(list_window, text="Eliminar producto", command=eliminar_producto, bd=1).grid(row=1, column=1, pady=10, padx=5, sticky="w")

    tk.Button(window, text="Buscar Producto", command=lambda:abrir_lista_productos(False), bd=1).grid(row=2, column=0, columnspan=2, pady=10)

    tk.Button(window, text="Filtrar por Mas Vendidos", command= lambda: abrir_lista_productos(True), bd=1).grid(row=3, column=0, columnspan=2, pady=10) 
def eliminar_productos(producto_db):
    window = tk.Toplevel()
    window.geometry("640x480+500+300")
    window.title("Eliminar producto")
    listbox = tk.Listbox(window)
    listbox.pack(fill=tk.BOTH, expand=True)
    prod_list = producto_db.VerProducto()

    for prd in prod_list:
        listbox.insert(tk.END, f"ID: {prd[0]}   |    Nombre: {prd[1]}   |   Precio: ${prd[3]}   |   Stock: {prd[4]}")

    def eliminar_producto():
        seleccion = listbox.curselection()
        producto_id = prod_list[seleccion[0]][0]
        producto_db.EliminarProducto(producto_id)
        messagebox.showinfo("Éxito", "Producto eliminado con éxito.")
        listbox.delete(seleccion)

    tk.Button(window, text="Eliminar producto", command=eliminar_producto).pack(pady=10)
    

def registrar_productos(producto_db):
    window = tk.Toplevel()
    window.geometry("700x300+500+500")
    window.title("Agregar producto")

    tk.Label(window, text="Nombre:").grid(row=0, column=0, padx=5, pady=10)
    nombre_entry = tk.Entry(window)
    nombre_entry.grid(row=0, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")

    tk.Label(window, text="Descripcion:").grid(row=1, column=0, padx=5, pady=10)
    descripcion_entry = tk.Entry(window)
    descripcion_entry.grid(row=1, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")

    tk.Label(window, text="Precio:").grid(row=2, column=0, padx=5, pady=10)
    precio_entry = tk.Entry(window)
    precio_entry.grid(row=2, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")

    tk.Label(window, text="Stock:").grid(row=3, column=0, padx=5, pady=10)
    stock_entry = tk.Entry(window)
    stock_entry.grid(row=3, column=1, padx=10, pady=10, ipadx=10, ipady=5, sticky="ew")

    def registrar_producto():
        nombre = nombre_entry.get().strip()
        descripcion = descripcion_entry.get().strip()
        precio = precio_entry.get().strip()
        stock = stock_entry.get().strip()
        if not nombre:
            messagebox.showerror("El campo 'Nombre' es obligatorio.")
            return
        if not descripcion:
            messagebox.showerror("El campo 'Descripcion' es obligatorio.")
            return
        try:
            precio = float(precio)
            if precio <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("El campo 'Precio' debe ser un número positivo.")
            return
        try:
            stock = int(stock)
            if stock < 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("El campo 'Stock' debe ser un número entero no negativo.")
            return
        producto_db.RegistrarProducto(nombre, descripcion, precio, stock)
        messagebox.showinfo("El producto ha sido registrado con éxito.")
        window.destroy()
    btn_RegistrarProducto = tk.Button(window, text="Registrar Producto", command=registrar_producto, bd=1)
    btn_RegistrarProducto.grid(row=5, column=0, columnspan=2, pady=20)
    
def ver_productos(producto_db):
    window = tk.Toplevel()
    window.geometry("640x480+500+300")
    window.title("Ver todos los productos")   
    listbox = tk.Listbox(window)
    listbox.pack(fill=tk.BOTH, expand=True)

    for producto in producto_db.VerProducto():
        listbox.insert(tk.END, f"ID: {producto[0]}   |    Nombre: {producto[1]}   |   Precio: ${producto[3]}   |   Stock: {producto[4]}")



   
