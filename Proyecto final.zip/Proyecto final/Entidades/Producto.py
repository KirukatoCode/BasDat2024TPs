from conexion import BaseDeDatos

class Producto:
    def __init__ (self,db):
        self.db = db
        
    def RegistrarProducto (self, Nombre:str, precio:float,stock:int,descripcion:str, categoria:str):
        query= "INSERT INTO Producto (Nombre, stock, descripcion, categoria) VALUES (%s, %s,%s, %s, %s)" 
        Valores= (Nombre, precio, stock, descripcion, categoria)
        self.db.EjecutarQuery(query, Valores)
        return "Producto registrado con éxito"
    
    def ActualizarProducto (self,id_producto, Nombre, precio, stock, descripcion, categoria):
        query= "UPDATE Producto SET Nombre= %s, precio= %s, stock=%s, descripcion=%s, categoria=%s WHERE id_producto=%s"
        Valores= (Nombre,precio, stock, descripcion, categoria)
        self.db.EjecutarQuery(query, Valores)
        return "Producto actualizado con éxito"
    
    def VerProducto(self):
        query= "SELECT * FROM Producto WHERE id_Producto=%s"
        return self.db.obtener_datos(query)
    
    def EliminarProducto (self,id_Producto):
        query= "DELETE FROM Producto WHERE id_Producto=%s"
        self.db.EjecutarQuery(query, (id_Producto))
        return "Producto eliminado con éxito"
    def ListarProductos(self):
        query= "SELECT * FROM Producto"
        return self.db.obtener_datos(query)
    
    def BuscarProductoporNombre(self, Nombre):
        try:
            cursor= self.db.cursor()
            consulta="""
                SELECT Nombre FROM Producto
                WHERE LOWER (Nombre) LIKE %s
                """
            busqueda =f"{Nombre.lower()}"
            cursor.execute(consulta, (busqueda,))
            resultado = cursor.fetchone()
            return resultado
        except Exception as e:
            print(f"Error: Producto no encontrado", e)
            return []
    
    def BuscarProductoporID(self, id_producto):
        query ="SELECT * FROM Product WHERE (id_producto LIKE %s)"
        valor=(f"%{id_producto}")
        return self.db.obtener_datos(query, valor)