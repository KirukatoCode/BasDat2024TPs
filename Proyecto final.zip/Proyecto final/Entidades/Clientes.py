from conexion import BaseDeDatos

class Cliente:
    def __init__(self, db):
        self.db = db

    def registrar_cliente(self, nombre, apellido, email, telefono):
        query ="INSERT INTO clientes (nombre, apellido, email, telefono) VALUES (%s,%s,,%s,%s)"
        valores= (nombre,apellido, email, telefono)
        self.db.ejecutar_query(query, valores)
        return "Cliente registrado con exito"
    def ver_cliente(self, id_cliente):
        query="SELECT * FROM clientes WHERE id_cliente = %s"
        return self.db.obtener_datos(query, id_cliente)
    def actualizar_cliente(self, id_cliente, nombre, apellido, email, telefono):
        query="UPDATE clientes SET nombre=%s, apellido=%s, email=%s, telefono=%s, WHERE id_cliente=%s"
        valores= (nombre, apellido, email, telefono, id_cliente)
        self.db.ejecutar_query(query, valores)
        return "Cliente actualizado con exito"
    def eliminar_cliente(self, id_cliente):
        query="DELETE FROM clientes WHERE id_cliente=%s"
        self.db.ejecutar_query(query, id_cliente)
        return "Cliente eliminado con exito"
    
    def buscar_cliente_por_nombre(self, nombre):
        query="SELECT * FROM clientes WHERE nombre LIKE %s"
        return self.db.obtener_datos(query, f'%{nombre}%')
    