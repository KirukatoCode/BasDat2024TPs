from conexion import BaseDeDatos
from datetime import datetime

class Ordendepedido:
    def __init__(self,db):
        self.db = db
        
    def registrar_orden(self, id_cliente, id_producto,cantidad, fecha):
        query= "CALL registro_orden( %s, %s, %s, %s)"
        valores= (id_cliente,id_producto,cantidad,fecha)
        fecha=datetime.now()
        try:
            self.db.ejecutar(query,valores)
            return "Orden de pedido ejecutrada"
        except Exception as e:
            return f"Error al registrar Orden"
    
    def ver_orden_id(self,id_orden):
        
        query= """
        SELECT o.id_orden, o.fecha, p.nombre, p.precio, o.cantidad, p.stock
        FROM OrdenPedido AS o
        INNER JOIN Productos AS p ON o.id_producto = p.id_producto
        WHERE o.id_orden = %s
        ORDER BY o.fecha_pedido DESC
        """
        self.db.ejecutar(query,id_orden)
    
    def eliminar_orden(self,id_orden):
        query= "DELETE FROM OrdenPedido WHERE id_orden = %s"
        self.db.ejecutar(query,id_orden)
        return "Orden eliminada correctamente"       
        
    def ver_ordenes(self):
        query= "SELECT * FROM OrdenPedido"
        return self.db.obtener_datos(query)
    
    def Listar_ordenes_por_cliente(self, id_cliente):
        query= "SELECT * FROM ordenes_por_cliente WHERE id_cliente = %s"
        valores= (id_cliente,)
        return self.db.obtener_datos(query,valores)
    
    def Listar_ordenes_por_producto(self, id_producto):
        query= "SELECT * FROM ordenes_por_producto WHERE id_producto = %s"
        valores= (id_producto,)
        return self.db.obtener_datos(query,valores)
    def actualizar_orden(self, id_orden, cantidad):
        query = "UPDATE ordenes SET cantidad=%s WHERE orden_id=%s"
        valores = (cantidad, id_orden)
        self.db.ejecutar(query, valores)
        return "Orden actualizada con éxito."
    