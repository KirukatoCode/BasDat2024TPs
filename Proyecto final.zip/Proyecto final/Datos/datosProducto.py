import tkinter as tk
from Repositorios.repo_productos import actualizar_productos, buscar_productos, eliminar_productos, registrar_productos, ver_productos

def mostrar_gestion_productos(producto_db):
    root = tk.Tk()
    root.title("Gestión de Productos")
    root.geometry("720x280")
    root.grid_columnconfigure(0, weight=1)

    tk.Button(root, text="Registrar Productos", padx=20, pady=10, bd=1,
              command=lambda: registrar_productos(producto_db)).grid(row=0, column=0, sticky="ew", padx=15, pady=5)

    tk.Button(root, text="Actualizar Producto", padx=20, pady=10, bd=1,
              command=lambda: actualizar_productos(producto_db)).grid(row=1, column=0, sticky="ew", padx=15, pady=5)

    tk.Button(root, text="Eliminar Producto", padx=20, pady=10, bd=1,
              command=lambda: eliminar_productos(producto_db)).grid(row=2, column=0, sticky="ew", padx=15, pady=5)

    tk.Button(root, text="Ver Productos", padx=20, pady=10, bd=1,
              command=lambda: ver_productos(producto_db)).grid(row=3, column=0, sticky="ew", padx=15, pady=5)

    tk.Button(root, text="Buscar Producto", padx=20, pady=10, bd=1,
              command=lambda: buscar_productos(producto_db)).grid(row=4, column=0, sticky="ew", padx=15, pady=5)
    root.mainloop()
