import tkinter as tk
from Repositorios.repo_clientes import mostrar_clientes, mostrar_actualizacion_cliente, buscar_clientes, Registrar_nuevo_cliente

def mostrar_gestion_clientes(cliente_db, ordenes_db):
    root = tk.Tk()
    root.geometry("720x300")
    root.title("Gestión de Clientes")
    root.grid_columnconfigure(0, weight=1)

    tk.Button(root, text="Ver Clientes", padx=20, pady=10, bd=1,
              command=lambda: mostrar_clientes(cliente_db)).grid(row=0, column=0, sticky="ew", padx=15, pady=5)
    
    tk.Button(root, text="Buscar clientes por Nombre", padx=20, pady=10, bd=1,
              command=lambda: buscar_clientes(cliente_db)).grid(row=1, column=0, sticky="ew", padx=15, pady=5)
    
    tk.Button(root, text="Nuevo Cliente", padx=20, pady=10, bd=1,
              command=lambda: Registrar_nuevo_cliente(cliente_db)).grid(row=2, column=0, sticky="ew", padx=15, pady=5)

    tk.Button(root, text="Actualizar Cliente", padx=20, pady=10, bd=1,
              command=lambda: mostrar_actualizacion_cliente(cliente_db)).grid(row=3, column=0, sticky="ew", padx=15, pady=5)

    tk.Button(root, text="Eliminar Cliente", padx=20, pady=10, bd=1,
              command=lambda: buscar_clientes(cliente_db)).grid(row=4, column=0, sticky="ew", padx=15, pady=5)
    
    root.mainloop()